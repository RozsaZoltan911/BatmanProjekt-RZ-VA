document.addEventListener("DOMContentLoaded", function () {
    setTimeout(function () {
        const leftLinks = document.querySelectorAll("nav ul.left li a");
        const rightLinks = document.querySelectorAll("nav ul.right li a");

        leftLinks.forEach((link, index) => {
            setTimeout(() => {
                link.style.opacity = 1;
                link.style.width = "auto";
            }, index * 200);
        });

        rightLinks.forEach((link, index) => {
            setTimeout(() => {
                link.style.opacity = 1;
                link.style.width = "auto";
            }, index * 200);
        });
    }, 4500);

    const navLinks = document.querySelectorAll("nav a");
    const header = document.querySelector("header");
    const logo = document.querySelector("nav .logo img");

    navLinks.forEach(link => {
        link.addEventListener("click", function (event) {
            event.preventDefault();
            const targetId = this.getAttribute("href").substring(1);
            const targetSection = document.getElementById(targetId);

            document.querySelectorAll("main section").forEach(section => {
                section.classList.remove("revealed");
                section.classList.add("hidden");
            });

            if (targetSection) {
                targetSection.classList.remove("hidden");
                targetSection.classList.add("revealed");
            }

            navLinks.forEach(link => link.classList.remove("active"));
            this.classList.add("active");
            header.classList.add("hidden");
        });
    });

    logo.addEventListener("click", function (event) {
        event.preventDefault();
        header.classList.remove("hidden");
        document.querySelectorAll("main section").forEach(section => {
            section.classList.remove("revealed");
            section.classList.add("hidden");
        });
    });

    const sections = document.querySelectorAll("main section");
    const observerOptions = {
        threshold: 0.5,
    };

    const observer = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add("revealed");
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    sections.forEach(section => {
        observer.observe(section);
    });
});